// variable for sound file
var ping;

// variable for webcam
var capture;

// variables for sine wave
var sine;
var freq = 400;

// variables for pacman animation
var radius = 30;
//var x = 0;
var speed = 1.0;
var direction = 1;

function preload() {
	ping = loadSound("Ping.wav");
}

function setup() {
	createCanvas(800, 800);

	// sound effect for pacman
	ellipseMode(RADIUS);
	x = 600;

	// webcam 
	capture = createCapture();
	capture.hide();

	// sine wave
	sine = new p5.SinOsc();
	sine.start();
}


function draw() {



	// sine wave sound
	var hertz = map(mouseX, 0, 400, 20.0, 440.0);

	sine.freq(hertz);





	// pacman animation with sound effect
	background(200);

	x += speed * direction;

	if ((x < 400 + radius) || (x > 800 - radius)) {

		direction = -direction;
		ping.play();

	}

	if (direction == 1) {
		fill(0);
		arc(x, 100, radius, radius, 0.52, 5.76);
	} else {
		fill(0);
		arc(x, 100, radius, radius, 3.67, 8.9);
}

	//sine wave animation
	for (var z = 0; z < 400; z++) {

		var angle = map(z, 0, 400, 0, TWO_PI * hertz);

		var sinValue = sin(angle) * 120;

		stroke(50);
		line(z, -200, z, 200 + sinValue);
		
	}

	// webcam
	var aspectRatio = capture.height/capture.width;
	var h = (width/2) * aspectRatio;
	image(capture, 400, 400, (width/2), h);
	filter(THRESHOLD);

}
